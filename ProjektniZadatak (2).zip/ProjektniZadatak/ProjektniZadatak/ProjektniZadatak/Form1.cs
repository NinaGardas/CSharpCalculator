﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ProjektniZadatak
{
    public partial class Kalkulator : Form
    {
        public Kalkulator()
        {
            InitializeComponent();
        }

        string opr;
        double br1, br2, rez;

        private void but1_Click(object sender, EventArgs e)
        {

            if (richTextBox.Text == "0" )
            {
                richTextBox.Text = "1";
            }
            else
            {
                richTextBox.Text += "1";
            }


        }

        private void but2_Click(object sender, EventArgs e)
        {
            if (richTextBox.Text == "0" )
            {
                richTextBox.Text = "2";
            }
            else
            {
                richTextBox.Text += "2";
            }
        }

        private void but3_Click(object sender, EventArgs e)
        {
            if (richTextBox.Text == "0" )
            {
                richTextBox.Text = "3";
            }
            else
            {
                richTextBox.Text += "3";
            }

        }

        private void but4_Click(object sender, EventArgs e)
        {
            if (richTextBox.Text == "0" )
            {
                richTextBox.Text = "4";
            }
            else
            {
                richTextBox.Text += "4";
            }

        }

        private void but5_Click(object sender, EventArgs e)
        {
            if (richTextBox.Text == "0" )
            {
                richTextBox.Text = "5";
            }
            else
            {
                richTextBox.Text += "5";
            }
        }

        private void but6_Click(object sender, EventArgs e)
        {
            if (richTextBox.Text == "0" )
            {
                richTextBox.Text = "6";
            }
            else
            {
                richTextBox.Text += "6";
            }

        }

        private void but7_Click(object sender, EventArgs e)
        {
            if (richTextBox.Text == "0" )
            {
                richTextBox.Text = "7";
            }
            else
            {
                richTextBox.Text += "7";
            }
        }

        private void but78_Click(object sender, EventArgs e)
        {
            if (richTextBox.Text == "0" )
            {
                richTextBox.Text = "8";
            }
            else
            {
                richTextBox.Text += "8";
            }
        }

        private void but9_Click(object sender, EventArgs e)
        {
            if (richTextBox.Text == "0" )
            {
                richTextBox.Text = "9";
            }
            else
            {
                richTextBox.Text += "9";
            }
        }

        private void but0_Click(object sender, EventArgs e)
        {
            if (richTextBox.Text == "0" )
            {
                richTextBox.Text = "0";
            }
            else
            {
                richTextBox.Text += "0";
            }
        }

        

        private void butJednako_Click(object sender, EventArgs e)
        {
            br2 = Convert.ToDouble(richTextBox.Text);
            switch (opr)
            {
                case "+":
                    rez = br1 + br2;
                    richTextBox.Text = Convert.ToString(rez);
                    
                    break;

                case "-":
                        rez = br1 - br2;
                        richTextBox.Text = Convert.ToString(rez);
                
                    break;

                case "*":
                    rez = br1 * br2;
                    richTextBox.Text = Convert.ToString(rez);

                    break;

                case "/":
                    if (br2 == 0)
                    {
                        richTextBox.Text = "Ne može se dijeliti s nulom. Stisnite C";
                        break;
                    }
                    else
                    {
                        rez = br1 / br2;
                        richTextBox.Text = Convert.ToString(rez);
                        break;
                    }

    
            }
        }

        private void butOduzimanje_Click(object sender, EventArgs e)
        {
            br1 = Convert.ToDouble(richTextBox.Text);
            opr = "-";
            richTextBox.Clear();
        }

        private void butMnoženje_Click(object sender, EventArgs e)
        {
            br1 = Convert.ToDouble(richTextBox.Text);
            opr = "*";
            richTextBox.Clear();

        }

        private void butKvadriranje_Click(object sender, EventArgs e)
        {

            richTextBox.Text = Math.Pow(Convert.ToDouble(richTextBox.Text),2).ToString();
    
        }

        private void butZbrajanje_Click(object sender, EventArgs e)
        {
            
            br1 = Convert.ToDouble(richTextBox.Text);
            opr = "+";
            richTextBox.Clear();

        }

        private void butKorijenovanje_Click(object sender, EventArgs e)
        {

            richTextBox.Text = Math.Sqrt(Convert.ToDouble(richTextBox.Text)).ToString();

        }

        private void butMinusMinus_Click(object sender, EventArgs e)
        {
            double mM= Convert.ToDouble(richTextBox.Text);
            richTextBox.Text = (-mM).ToString();
        }

        private void butDijeljenje_Click(object sender, EventArgs e)
        {
            br1 = Convert.ToDouble(richTextBox.Text);
            opr = "/";
            richTextBox.Clear();

        }

        private void butBrisanje_Click(object sender, EventArgs e)
        {
            richTextBox.Clear();
            br1 = 0;
            br2 = 0;
        }









    }



}

