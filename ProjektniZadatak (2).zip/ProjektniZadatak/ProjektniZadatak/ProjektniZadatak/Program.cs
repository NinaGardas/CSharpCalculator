﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjektniZadatak
{
    class Program
    {
        static void Main(string[] args)
        {
            Logger log = new Logger();

            log.DodajLog("test");

            log.DodajLog("Podatci iz početne datoteke su učitani.");

            Application.Run(new Kalkulator());
        }
    }
}
