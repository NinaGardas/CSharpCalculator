﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektniZadatak
{
    public class Logger
    {
        public void DodajLog(string text)
        {
            string log = $"\n-- MAIN LOG: {DateTime.Now} - {text} --";
                        
            File.AppendAllText("log.txt", log);
        }
    }
}
