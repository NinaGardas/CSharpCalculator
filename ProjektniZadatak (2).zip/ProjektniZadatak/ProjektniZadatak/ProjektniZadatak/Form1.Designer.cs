﻿namespace ProjektniZadatak
{
    partial class Kalkulator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.but7 = new System.Windows.Forms.Button();
            this.but78 = new System.Windows.Forms.Button();
            this.but9 = new System.Windows.Forms.Button();
            this.but4 = new System.Windows.Forms.Button();
            this.but5 = new System.Windows.Forms.Button();
            this.but6 = new System.Windows.Forms.Button();
            this.but1 = new System.Windows.Forms.Button();
            this.but2 = new System.Windows.Forms.Button();
            this.but3 = new System.Windows.Forms.Button();
            this.but0 = new System.Windows.Forms.Button();
            this.butDijeljenje = new System.Windows.Forms.Button();
            this.butMnoženje = new System.Windows.Forms.Button();
            this.butOduzimanje = new System.Windows.Forms.Button();
            this.butZbrajanje = new System.Windows.Forms.Button();
            this.butKvadriranje = new System.Windows.Forms.Button();
            this.butKorijenovanje = new System.Windows.Forms.Button();
            this.butJednako = new System.Windows.Forms.Button();
            this.richTextBox = new System.Windows.Forms.RichTextBox();
            this.butBrisanje = new System.Windows.Forms.Button();
            this.butMinusMinus = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // but7
            // 
            this.but7.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.but7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.but7.Location = new System.Drawing.Point(31, 125);
            this.but7.Name = "but7";
            this.but7.Size = new System.Drawing.Size(56, 54);
            this.but7.TabIndex = 0;
            this.but7.Text = "7";
            this.but7.UseVisualStyleBackColor = false;
            this.but7.Click += new System.EventHandler(this.but7_Click);
            // 
            // but78
            // 
            this.but78.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.but78.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.but78.Location = new System.Drawing.Point(93, 125);
            this.but78.Name = "but78";
            this.but78.Size = new System.Drawing.Size(56, 54);
            this.but78.TabIndex = 1;
            this.but78.Text = "8";
            this.but78.UseVisualStyleBackColor = false;
            this.but78.Click += new System.EventHandler(this.but78_Click);
            // 
            // but9
            // 
            this.but9.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.but9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.but9.Location = new System.Drawing.Point(155, 125);
            this.but9.Name = "but9";
            this.but9.Size = new System.Drawing.Size(56, 54);
            this.but9.TabIndex = 2;
            this.but9.Text = "9";
            this.but9.UseVisualStyleBackColor = false;
            this.but9.Click += new System.EventHandler(this.but9_Click);
            // 
            // but4
            // 
            this.but4.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.but4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.but4.Location = new System.Drawing.Point(31, 185);
            this.but4.Name = "but4";
            this.but4.Size = new System.Drawing.Size(56, 54);
            this.but4.TabIndex = 3;
            this.but4.Text = "4";
            this.but4.UseVisualStyleBackColor = false;
            this.but4.Click += new System.EventHandler(this.but4_Click);
            // 
            // but5
            // 
            this.but5.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.but5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.but5.Location = new System.Drawing.Point(93, 185);
            this.but5.Name = "but5";
            this.but5.Size = new System.Drawing.Size(56, 54);
            this.but5.TabIndex = 4;
            this.but5.Text = "5";
            this.but5.UseVisualStyleBackColor = false;
            this.but5.Click += new System.EventHandler(this.but5_Click);
            // 
            // but6
            // 
            this.but6.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.but6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.but6.Location = new System.Drawing.Point(155, 185);
            this.but6.Name = "but6";
            this.but6.Size = new System.Drawing.Size(56, 54);
            this.but6.TabIndex = 5;
            this.but6.Text = "6";
            this.but6.UseVisualStyleBackColor = false;
            this.but6.Click += new System.EventHandler(this.but6_Click);
            // 
            // but1
            // 
            this.but1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.but1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but1.Location = new System.Drawing.Point(31, 245);
            this.but1.Name = "but1";
            this.but1.Size = new System.Drawing.Size(56, 54);
            this.but1.TabIndex = 6;
            this.but1.Text = "1";
            this.but1.UseVisualStyleBackColor = false;
            this.but1.Click += new System.EventHandler(this.but1_Click);
            // 
            // but2
            // 
            this.but2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.but2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.but2.Location = new System.Drawing.Point(93, 245);
            this.but2.Name = "but2";
            this.but2.Size = new System.Drawing.Size(56, 54);
            this.but2.TabIndex = 7;
            this.but2.Text = "2";
            this.but2.UseVisualStyleBackColor = false;
            this.but2.Click += new System.EventHandler(this.but2_Click);
            // 
            // but3
            // 
            this.but3.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.but3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.but3.Location = new System.Drawing.Point(155, 245);
            this.but3.Name = "but3";
            this.but3.Size = new System.Drawing.Size(56, 54);
            this.but3.TabIndex = 8;
            this.but3.Text = "3";
            this.but3.UseVisualStyleBackColor = false;
            this.but3.Click += new System.EventHandler(this.but3_Click);
            // 
            // but0
            // 
            this.but0.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.but0.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.but0.ForeColor = System.Drawing.SystemColors.ControlText;
            this.but0.Location = new System.Drawing.Point(93, 305);
            this.but0.Name = "but0";
            this.but0.Size = new System.Drawing.Size(56, 54);
            this.but0.TabIndex = 9;
            this.but0.Text = "0";
            this.but0.UseVisualStyleBackColor = false;
            this.but0.Click += new System.EventHandler(this.but0_Click);
            // 
            // butDijeljenje
            // 
            this.butDijeljenje.BackColor = System.Drawing.Color.Aquamarine;
            this.butDijeljenje.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.butDijeljenje.Location = new System.Drawing.Point(346, 185);
            this.butDijeljenje.Name = "butDijeljenje";
            this.butDijeljenje.Size = new System.Drawing.Size(56, 54);
            this.butDijeljenje.TabIndex = 10;
            this.butDijeljenje.Text = "÷";
            this.butDijeljenje.UseVisualStyleBackColor = false;
            this.butDijeljenje.Click += new System.EventHandler(this.butDijeljenje_Click);
            // 
            // butMnoženje
            // 
            this.butMnoženje.BackColor = System.Drawing.Color.Aquamarine;
            this.butMnoženje.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.butMnoženje.Location = new System.Drawing.Point(346, 125);
            this.butMnoženje.Name = "butMnoženje";
            this.butMnoženje.Size = new System.Drawing.Size(56, 54);
            this.butMnoženje.TabIndex = 11;
            this.butMnoženje.Text = "×";
            this.butMnoženje.UseVisualStyleBackColor = false;
            this.butMnoženje.Click += new System.EventHandler(this.butMnoženje_Click);
            // 
            // butOduzimanje
            // 
            this.butOduzimanje.BackColor = System.Drawing.Color.Aquamarine;
            this.butOduzimanje.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.butOduzimanje.Location = new System.Drawing.Point(255, 185);
            this.butOduzimanje.Name = "butOduzimanje";
            this.butOduzimanje.Size = new System.Drawing.Size(56, 54);
            this.butOduzimanje.TabIndex = 12;
            this.butOduzimanje.Text = "-";
            this.butOduzimanje.UseVisualStyleBackColor = false;
            this.butOduzimanje.Click += new System.EventHandler(this.butOduzimanje_Click);
            // 
            // butZbrajanje
            // 
            this.butZbrajanje.BackColor = System.Drawing.Color.Aquamarine;
            this.butZbrajanje.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butZbrajanje.Location = new System.Drawing.Point(255, 125);
            this.butZbrajanje.Name = "butZbrajanje";
            this.butZbrajanje.Size = new System.Drawing.Size(56, 54);
            this.butZbrajanje.TabIndex = 13;
            this.butZbrajanje.Text = "+";
            this.butZbrajanje.UseVisualStyleBackColor = false;
            this.butZbrajanje.Click += new System.EventHandler(this.butZbrajanje_Click);
            // 
            // butKvadriranje
            // 
            this.butKvadriranje.BackColor = System.Drawing.Color.Aquamarine;
            this.butKvadriranje.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.butKvadriranje.Location = new System.Drawing.Point(255, 245);
            this.butKvadriranje.Name = "butKvadriranje";
            this.butKvadriranje.Size = new System.Drawing.Size(56, 54);
            this.butKvadriranje.TabIndex = 14;
            this.butKvadriranje.Text = "x²";
            this.butKvadriranje.UseVisualStyleBackColor = false;
            this.butKvadriranje.Click += new System.EventHandler(this.butKvadriranje_Click);
            // 
            // butKorijenovanje
            // 
            this.butKorijenovanje.BackColor = System.Drawing.Color.Aquamarine;
            this.butKorijenovanje.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.butKorijenovanje.Location = new System.Drawing.Point(346, 245);
            this.butKorijenovanje.Name = "butKorijenovanje";
            this.butKorijenovanje.Size = new System.Drawing.Size(56, 54);
            this.butKorijenovanje.TabIndex = 15;
            this.butKorijenovanje.Text = "√x";
            this.butKorijenovanje.UseVisualStyleBackColor = false;
            this.butKorijenovanje.Click += new System.EventHandler(this.butKorijenovanje_Click);
            // 
            // butJednako
            // 
            this.butJednako.BackColor = System.Drawing.Color.PaleGreen;
            this.butJednako.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.butJednako.Location = new System.Drawing.Point(255, 305);
            this.butJednako.Name = "butJednako";
            this.butJednako.Size = new System.Drawing.Size(147, 54);
            this.butJednako.TabIndex = 16;
            this.butJednako.Text = "=";
            this.butJednako.UseVisualStyleBackColor = false;
            this.butJednako.Click += new System.EventHandler(this.butJednako_Click);
            // 
            // richTextBox
            // 
            this.richTextBox.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox.Location = new System.Drawing.Point(31, 13);
            this.richTextBox.Name = "richTextBox";
            this.richTextBox.Size = new System.Drawing.Size(371, 96);
            this.richTextBox.TabIndex = 17;
            this.richTextBox.Text = "";
            // 
            // butBrisanje
            // 
            this.butBrisanje.BackColor = System.Drawing.Color.Salmon;
            this.butBrisanje.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butBrisanje.Location = new System.Drawing.Point(155, 305);
            this.butBrisanje.Name = "butBrisanje";
            this.butBrisanje.Size = new System.Drawing.Size(56, 54);
            this.butBrisanje.TabIndex = 18;
            this.butBrisanje.Text = "C";
            this.butBrisanje.UseVisualStyleBackColor = false;
            this.butBrisanje.Click += new System.EventHandler(this.butBrisanje_Click);
            // 
            // butMinusMinus
            // 
            this.butMinusMinus.BackColor = System.Drawing.Color.Plum;
            this.butMinusMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butMinusMinus.Location = new System.Drawing.Point(31, 305);
            this.butMinusMinus.Name = "butMinusMinus";
            this.butMinusMinus.Size = new System.Drawing.Size(56, 54);
            this.butMinusMinus.TabIndex = 19;
            this.butMinusMinus.Text = "(-)";
            this.butMinusMinus.UseVisualStyleBackColor = false;
            this.butMinusMinus.Click += new System.EventHandler(this.butMinusMinus_Click);
            // 
            // Kalkulator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.ClientSize = new System.Drawing.Size(435, 383);
            this.Controls.Add(this.butMinusMinus);
            this.Controls.Add(this.butBrisanje);
            this.Controls.Add(this.richTextBox);
            this.Controls.Add(this.butJednako);
            this.Controls.Add(this.butKorijenovanje);
            this.Controls.Add(this.butKvadriranje);
            this.Controls.Add(this.butZbrajanje);
            this.Controls.Add(this.butOduzimanje);
            this.Controls.Add(this.butMnoženje);
            this.Controls.Add(this.butDijeljenje);
            this.Controls.Add(this.but0);
            this.Controls.Add(this.but3);
            this.Controls.Add(this.but2);
            this.Controls.Add(this.but1);
            this.Controls.Add(this.but6);
            this.Controls.Add(this.but5);
            this.Controls.Add(this.but4);
            this.Controls.Add(this.but9);
            this.Controls.Add(this.but78);
            this.Controls.Add(this.but7);
            this.Name = "Kalkulator";
            this.Text = "Kalkulator";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button but7;
        private System.Windows.Forms.Button but78;
        private System.Windows.Forms.Button but9;
        private System.Windows.Forms.Button but4;
        private System.Windows.Forms.Button but5;
        private System.Windows.Forms.Button but6;
        private System.Windows.Forms.Button but1;
        private System.Windows.Forms.Button but2;
        private System.Windows.Forms.Button but3;
        private System.Windows.Forms.Button but0;
        private System.Windows.Forms.Button butDijeljenje;
        private System.Windows.Forms.Button butMnoženje;
        private System.Windows.Forms.Button butOduzimanje;
        private System.Windows.Forms.Button butZbrajanje;
        private System.Windows.Forms.Button butKvadriranje;
        private System.Windows.Forms.Button butKorijenovanje;
        private System.Windows.Forms.Button butJednako;
        private System.Windows.Forms.RichTextBox richTextBox;
        private System.Windows.Forms.Button butBrisanje;
        private System.Windows.Forms.Button butMinusMinus;
    }
}